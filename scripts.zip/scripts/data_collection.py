"""
Data Collection Module - Milestone 1
Collects, validates, and catalogs Aadhaar documents for OCR processing.
"""

import os
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple
import yaml
from PIL import Image
import pandas as pd
from tqdm import tqdm

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DataCollector:
    """Handles data collection and validation for Aadhaar documents."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Initialize DataCollector with configuration."""
        self.config = self._load_config(config_path)
        self.stats = {
            'total_found': 0,
            'valid': 0,
            'invalid': 0,
            'errors': []
        }
        
    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise
    
    def validate_image(self, image_path: str) -> Tuple[bool, str]:
        """
        Validate image file for OCR processing.
        
        Args:
            image_path: Path to image file
            
        Returns:
            Tuple of (is_valid, reason)
        """
        try:
            # Check file exists
            if not os.path.exists(image_path):
                return False, "File not found"
            
            # Check file size
            file_size_mb = os.path.getsize(image_path) / (1024 * 1024)
            max_size = self.config['preprocessing']['max_file_size_mb']
            min_size = self.config['preprocessing']['min_file_size_kb'] / 1024
            
            if file_size_mb > max_size:
                return False, f"File too large: {file_size_mb:.2f}MB > {max_size}MB"
            if file_size_mb < min_size:
                return False, f"File too small: {file_size_mb:.2f}MB < {min_size}MB"
            
            # Check file format
            ext = os.path.splitext(image_path)[1].lower()
            supported_formats = self.config['preprocessing']['supported_formats']
            if ext not in supported_formats:
                return False, f"Unsupported format: {ext}"
            
            # Check image can be opened and dimensions
            with Image.open(image_path) as img:
                width, height = img.size
                min_width = self.config['preprocessing']['min_width']
                min_height = self.config['preprocessing']['min_height']
                
                if width < min_width or height < min_height:
                    return False, f"Image too small: {width}x{height} < {min_width}x{min_height}"
                
                # Check if image is corrupted
                img.verify()
            
            return True, "Valid"
            
        except Exception as e:
            return False, f"Validation error: {str(e)}"
    
    def extract_metadata(self, image_path: str) -> Dict:
        """
        Extract metadata from image file.
        
        Args:
            image_path: Path to image file
            
        Returns:
            Dictionary containing image metadata
        """
        try:
            stat = os.stat(image_path)
            
            with Image.open(image_path) as img:
                metadata = {
                    'filename': os.path.basename(image_path),
                    'filepath': image_path,
                    'file_size_bytes': stat.st_size,
                    'file_size_mb': stat.st_size / (1024 * 1024),
                    'format': img.format,
                    'mode': img.mode,
                    'width': img.width,
                    'height': img.height,
                    'dpi': img.info.get('dpi', (None, None)),
                    'created_date': datetime.fromtimestamp(stat.st_ctime).isoformat(),
                    'modified_date': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    'collected_date': datetime.now().isoformat(),
                }
                
                # Add EXIF data if available
                exif_data = img.getexif()
                if exif_data:
                    metadata['exif_available'] = True
                else:
                    metadata['exif_available'] = False
                    
            return metadata
            
        except Exception as e:
            logger.error(f"Failed to extract metadata from {image_path}: {e}")
            return {}
    
    def collect_documents(self) -> pd.DataFrame:
        """
        Collect and catalog all Aadhaar documents.
        
        Returns:
            DataFrame containing document catalog
        """
        raw_path = self.config['paths']['raw_images']
        logger.info(f"Collecting documents from: {raw_path}")
        
        if not os.path.exists(raw_path):
            logger.error(f"Raw data path not found: {raw_path}")
            raise FileNotFoundError(f"Raw data path not found: {raw_path}")
        
        # Collect all image files
        image_files = []
        supported_formats = self.config['preprocessing']['supported_formats']
        
        for ext in supported_formats:
            image_files.extend(Path(raw_path).glob(f"*{ext}"))
            image_files.extend(Path(raw_path).glob(f"*{ext.upper()}"))
        
        self.stats['total_found'] = len(image_files)
        logger.info(f"Found {len(image_files)} image files")
        
        # Process each image
        catalog_data = []
        
        for img_path in tqdm(image_files, desc="Cataloging documents"):
            img_path_str = str(img_path)
            
            # Validate image
            is_valid, validation_msg = self.validate_image(img_path_str)
            
            # Extract metadata
            metadata = self.extract_metadata(img_path_str)
            metadata['is_valid'] = is_valid
            metadata['validation_message'] = validation_msg
            
            catalog_data.append(metadata)
            
            if is_valid:
                self.stats['valid'] += 1
            else:
                self.stats['invalid'] += 1
                self.stats['errors'].append({
                    'file': os.path.basename(img_path_str),
                    'reason': validation_msg
                })
        
        # Create DataFrame
        df = pd.DataFrame(catalog_data)
        
        # Save catalog
        self._save_catalog(df)
        
        # Generate report
        self._generate_collection_report(df)
        
        return df
    
    def _save_catalog(self, df: pd.DataFrame):
        """Save document catalog to file."""
        metadata_path = self.config['paths']['metadata']
        os.makedirs(metadata_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save as CSV
        csv_path = os.path.join(metadata_path, f"document_catalog_{timestamp}.csv")
        df.to_csv(csv_path, index=False)
        logger.info(f"Catalog saved to: {csv_path}")
        
        # Save as Excel
        excel_path = os.path.join(metadata_path, f"document_catalog_{timestamp}.xlsx")
        df.to_excel(excel_path, index=False, engine='openpyxl')
        logger.info(f"Catalog saved to: {excel_path}")
        
        # Save as JSON
        json_path = os.path.join(metadata_path, f"document_catalog_{timestamp}.json")
        df.to_json(json_path, orient='records', indent=2)
        logger.info(f"Catalog saved to: {json_path}")
    
    def _generate_collection_report(self, df: pd.DataFrame):
        """Generate collection summary report."""
        report_path = self.config['paths']['validation_reports']
        os.makedirs(report_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(report_path, f"collection_report_{timestamp}.txt")
        
        with open(report_file, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("DATA COLLECTION REPORT - MILESTONE 1\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Collection Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Source Path: {self.config['paths']['raw_images']}\n\n")
            
            f.write("SUMMARY STATISTICS\n")
            f.write("-" * 80 + "\n")
            f.write(f"Total Documents Found: {self.stats['total_found']}\n")
            f.write(f"Valid Documents: {self.stats['valid']}\n")
            f.write(f"Invalid Documents: {self.stats['invalid']}\n")
            f.write(f"Validation Rate: {(self.stats['valid']/self.stats['total_found']*100):.2f}%\n\n")
            
            if not df.empty:
                valid_df = df[df['is_valid'] == True]
                
                f.write("IMAGE STATISTICS (Valid Documents)\n")
                f.write("-" * 80 + "\n")
                f.write(f"Average File Size: {valid_df['file_size_mb'].mean():.2f} MB\n")
                f.write(f"Average Dimensions: {valid_df['width'].mean():.0f} x {valid_df['height'].mean():.0f}\n")
                f.write(f"Formats: {valid_df['format'].value_counts().to_dict()}\n")
                f.write(f"Modes: {valid_df['mode'].value_counts().to_dict()}\n\n")
            
            if self.stats['errors']:
                f.write("VALIDATION ERRORS\n")
                f.write("-" * 80 + "\n")
                for error in self.stats['errors'][:20]:  # Show first 20 errors
                    f.write(f"  • {error['file']}: {error['reason']}\n")
                if len(self.stats['errors']) > 20:
                    f.write(f"  ... and {len(self.stats['errors']) - 20} more errors\n")
        
        logger.info(f"Collection report saved to: {report_file}")
        
        # Print summary
        print("\n" + "=" * 80)
        print("DATA COLLECTION COMPLETED")
        print("=" * 80)
        print(f"Total Documents: {self.stats['total_found']}")
        print(f"Valid: {self.stats['valid']} | Invalid: {self.stats['invalid']}")
        print(f"Validation Rate: {(self.stats['valid']/self.stats['total_found']*100):.2f}%")
        print(f"Report: {report_file}")
        print("=" * 80 + "\n")


def main():
    """Main execution function."""
    try:
        # Initialize collector
        collector = DataCollector()
        
        # Collect and catalog documents
        catalog_df = collector.collect_documents()
        
        logger.info("Data collection completed successfully!")
        
    except Exception as e:
        logger.error(f"Data collection failed: {e}")
        raise


if __name__ == "__main__":
    main()
