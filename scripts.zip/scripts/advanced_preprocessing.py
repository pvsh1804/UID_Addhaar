"""
Advanced Preprocessing Module - Milestone 1
Enhanced image preprocessing with quality checks and Azure AI compatibility.
"""

import os
import logging
import numpy as np
import cv2
import yaml
from datetime import datetime
from pathlib import Path
from typing import Dict, Tuple, Optional
import pandas as pd
from tqdm import tqdm
from PIL import Image
from skimage.filters import threshold_otsu
import imutils

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ImagePreprocessor:
    """Advanced image preprocessing for Aadhaar documents."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Initialize preprocessor with configuration."""
        self.config = self._load_config(config_path)
        self.stats = {
            'total_processed': 0,
            'successful': 0,
            'failed': 0,
            'quality_issues': []
        }
    
    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise
    
    def check_image_blur(self, image: np.ndarray) -> Tuple[float, bool]:
        """
        Check if image is blurry using Laplacian variance.
        
        Args:
            image: Input image (grayscale or BGR)
            
        Returns:
            Tuple of (blur_score, is_blurry)
        """
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Calculate Laplacian variance
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        threshold = self.config['preprocessing']['blur_threshold']
        is_blurry = laplacian_var < threshold
        
        return laplacian_var, is_blurry
    
    def check_brightness(self, image: np.ndarray) -> Tuple[float, bool]:
        """
        Check image brightness.
        
        Args:
            image: Input image
            
        Returns:
            Tuple of (brightness_score, is_good)
        """
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        brightness = np.mean(gray)
        
        min_bright, max_bright = self.config['preprocessing']['brightness_range']
        is_good = min_bright <= brightness <= max_bright
        
        return brightness, is_good
    
    def deskew_image(self, image: np.ndarray) -> np.ndarray:
        """
        Deskew image by detecting and correcting rotation.
        
        Args:
            image: Input image
            
        Returns:
            Deskewed image
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Apply threshold
        thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
        
        # Find contours
        coords = np.column_stack(np.where(thresh > 0))
        
        if len(coords) == 0:
            return image
        
        # Calculate rotation angle
        angle = cv2.minAreaRect(coords)[-1]
        
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        
        # Rotate image if angle is significant
        if abs(angle) > 0.5:
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(image, M, (w, h),
                                    flags=cv2.INTER_CUBIC,
                                    borderMode=cv2.BORDER_REPLICATE)
            return rotated
        
        return image
    
    def preprocess_image(self, image_path: str, output_dir: str) -> Dict:
        """
        Apply comprehensive preprocessing to image.
        
        Args:
            image_path: Path to input image
            output_dir: Directory to save processed image
            
        Returns:
            Dictionary with processing results and metrics
        """
        try:
            # Read image
            img = cv2.imread(image_path)
            if img is None:
                raise ValueError(f"Failed to load image: {image_path}")
            
            original_shape = img.shape
            
            # Quality checks
            blur_score, is_blurry = self.check_image_blur(img)
            brightness, is_bright_ok = self.check_brightness(img)
            
            quality_issues = []
            if is_blurry:
                quality_issues.append(f"Blurry image (score: {blur_score:.2f})")
            if not is_bright_ok:
                quality_issues.append(f"Poor brightness (value: {brightness:.2f})")
            
            # Start preprocessing pipeline
            processed = img.copy()
            
            # 1. Deskew if enabled
            if self.config['preprocessing']['techniques']['deskew']:
                processed = self.deskew_image(processed)
            
            # 2. Convert to grayscale if enabled
            if self.config['preprocessing']['techniques']['grayscale']:
                processed = cv2.cvtColor(processed, cv2.COLOR_BGR2GRAY)
            
            # 3. Denoise if enabled
            if self.config['preprocessing']['techniques']['denoise']:
                h = self.config['preprocessing']['denoise_strength']
                template_size = self.config['preprocessing']['denoise_template_window']
                search_size = self.config['preprocessing']['denoise_search_window']
                processed = cv2.fastNlMeansDenoising(processed, None, h, template_size, search_size)
            
            # 4. Apply thresholding if enabled
            if self.config['preprocessing']['techniques']['threshold']:
                # Use Otsu's method for better results
                _, processed = cv2.threshold(processed, 0, 255, 
                                           cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # Save processed image
            filename = os.path.basename(image_path)
            output_path = os.path.join(output_dir, filename)
            
            # Ensure output format is correct
            output_format = self.config['preprocessing']['output_format']
            if not filename.lower().endswith(f'.{output_format}'):
                name_without_ext = os.path.splitext(filename)[0]
                output_path = os.path.join(output_dir, f"{name_without_ext}.{output_format}")
            
            cv2.imwrite(output_path, processed)
            
            # Prepare result
            result = {
                'input_path': image_path,
                'output_path': output_path,
                'success': True,
                'original_shape': original_shape,
                'processed_shape': processed.shape,
                'blur_score': blur_score,
                'is_blurry': is_blurry,
                'brightness': brightness,
                'brightness_ok': is_bright_ok,
                'quality_issues': quality_issues,
                'processed_date': datetime.now().isoformat()
            }
            
            if quality_issues:
                self.stats['quality_issues'].append({
                    'file': filename,
                    'issues': quality_issues
                })
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to preprocess {image_path}: {e}")
            return {
                'input_path': image_path,
                'output_path': None,
                'success': False,
                'error': str(e)
            }
    
    def preprocess_batch(self, input_dir: str = None, output_dir: str = None) -> pd.DataFrame:
        """
        Preprocess batch of images.
        
        Args:
            input_dir: Input directory (uses config if None)
            output_dir: Output directory (uses config if None)
            
        Returns:
            DataFrame with processing results
        """
        if input_dir is None:
            input_dir = self.config['paths']['raw_images']
        if output_dir is None:
            output_dir = self.config['paths']['preprocessed']
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        logger.info(f"Preprocessing images from: {input_dir}")
        logger.info(f"Saving to: {output_dir}")
        
        # Get all image files
        supported_formats = self.config['preprocessing']['supported_formats']
        image_files = []
        
        for ext in supported_formats:
            image_files.extend(Path(input_dir).glob(f"*{ext}"))
            image_files.extend(Path(input_dir).glob(f"*{ext.upper()}"))
        
        logger.info(f"Found {len(image_files)} images to process")
        
        # Process each image
        results = []
        
        for img_path in tqdm(image_files, desc="Preprocessing images"):
            result = self.preprocess_image(str(img_path), output_dir)
            results.append(result)
            
            if result['success']:
                self.stats['successful'] += 1
            else:
                self.stats['failed'] += 1
            
            self.stats['total_processed'] += 1
        
        # Create results DataFrame
        df = pd.DataFrame(results)
        
        # Save results
        self._save_preprocessing_results(df)
        
        # Generate report
        self._generate_preprocessing_report(df)
        
        return df
    
    def _save_preprocessing_results(self, df: pd.DataFrame):
        """Save preprocessing results to file."""
        metadata_path = self.config['paths']['metadata']
        os.makedirs(metadata_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save as CSV
        csv_path = os.path.join(metadata_path, f"preprocessing_results_{timestamp}.csv")
        df.to_csv(csv_path, index=False)
        logger.info(f"Results saved to: {csv_path}")
    
    def _generate_preprocessing_report(self, df: pd.DataFrame):
        """Generate preprocessing report."""
        report_path = self.config['paths']['validation_reports']
        os.makedirs(report_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(report_path, f"preprocessing_report_{timestamp}.txt")
        
        with open(report_file, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("IMAGE PREPROCESSING REPORT - MILESTONE 1\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Processing Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Input Directory: {self.config['paths']['raw_images']}\n")
            f.write(f"Output Directory: {self.config['paths']['preprocessed']}\n\n")
            
            f.write("SUMMARY STATISTICS\n")
            f.write("-" * 80 + "\n")
            f.write(f"Total Images Processed: {self.stats['total_processed']}\n")
            f.write(f"Successful: {self.stats['successful']}\n")
            f.write(f"Failed: {self.stats['failed']}\n")
            f.write(f"Success Rate: {(self.stats['successful']/self.stats['total_processed']*100):.2f}%\n\n")
            
            if not df.empty:
                success_df = df[df['success'] == True]
                
                if len(success_df) > 0:
                    f.write("QUALITY METRICS\n")
                    f.write("-" * 80 + "\n")
                    f.write(f"Average Blur Score: {success_df['blur_score'].mean():.2f}\n")
                    f.write(f"Blurry Images: {success_df['is_blurry'].sum()}\n")
                    f.write(f"Average Brightness: {success_df['brightness'].mean():.2f}\n")
                    f.write(f"Images with Poor Brightness: {(~success_df['brightness_ok']).sum()}\n\n")
            
            if self.stats['quality_issues']:
                f.write("QUALITY ISSUES\n")
                f.write("-" * 80 + "\n")
                for issue in self.stats['quality_issues'][:20]:
                    f.write(f"  • {issue['file']}:\n")
                    for i in issue['issues']:
                        f.write(f"      - {i}\n")
                if len(self.stats['quality_issues']) > 20:
                    f.write(f"  ... and {len(self.stats['quality_issues']) - 20} more issues\n")
        
        logger.info(f"Preprocessing report saved to: {report_file}")
        
        # Print summary
        print("\n" + "=" * 80)
        print("IMAGE PREPROCESSING COMPLETED")
        print("=" * 80)
        print(f"Total Processed: {self.stats['total_processed']}")
        print(f"Successful: {self.stats['successful']} | Failed: {self.stats['failed']}")
        print(f"Success Rate: {(self.stats['successful']/self.stats['total_processed']*100):.2f}%")
        print(f"Quality Issues: {len(self.stats['quality_issues'])}")
        print(f"Report: {report_file}")
        print("=" * 80 + "\n")


def main():
    """Main execution function."""
    try:
        # Initialize preprocessor
        preprocessor = ImagePreprocessor()
        
        # Preprocess batch
        results_df = preprocessor.preprocess_batch()
        
        logger.info("Preprocessing completed successfully!")
        
    except Exception as e:
        logger.error(f"Preprocessing failed: {e}")
        raise


if __name__ == "__main__":
    main()
