"""
Azure AI Document Intelligence Preparation Module - Milestone 1
Prepares documents for Azure AI Document Intelligence processing.
"""

import os
import logging
import yaml
from datetime import datetime
from pathlib import Path
from typing import Dict, List
import pandas as pd
from tqdm import tqdm
from PIL import Image
import shutil
from dotenv import load_dotenv

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()


class AzureDocumentPrep:
    """Prepare documents for Azure AI Document Intelligence."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Initialize Azure document prep with configuration."""
        self.config = self._load_config(config_path)
        self.stats = {
            'total_processed': 0,
            'azure_ready': 0,
            'rejected': 0,
            'issues': []
        }
        
        # Check Azure credentials
        self.endpoint = os.getenv('AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT')
        self.key = os.getenv('AZURE_DOCUMENT_INTELLIGENCE_KEY')
        
        if not self.endpoint or not self.key:
            logger.warning("Azure credentials not found in environment. "
                         "Set them in .env file for API testing.")
    
    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise
    
    def validate_for_azure(self, image_path: str) -> tuple[bool, str]:
        """
        Validate if image meets Azure AI Document Intelligence requirements.
        
        Azure Requirements:
        - Supported formats: JPEG, PNG, BMP, TIFF, PDF
        - File size: < 4 MB
        - Dimensions: >= 50 x 50 pixels, <= 10,000 x 10,000 pixels
        - Recommended DPI: 200-300 for text
        
        Args:
            image_path: Path to image file
            
        Returns:
            Tuple of (is_valid, reason)
        """
        try:
            # Check file exists
            if not os.path.exists(image_path):
                return False, "File not found"
            
            # Check file size (Azure limit is 4MB)
            file_size_mb = os.path.getsize(image_path) / (1024 * 1024)
            max_size = self.config['azure']['max_image_size_mb']
            
            if file_size_mb > max_size:
                return False, f"File exceeds Azure limit: {file_size_mb:.2f}MB > {max_size}MB"
            
            # Check format
            ext = os.path.splitext(image_path)[1].lower()
            supported_formats = self.config['azure']['supported_formats']
            
            if ext not in supported_formats:
                return False, f"Format not supported by Azure: {ext}"
            
            # Check image dimensions
            with Image.open(image_path) as img:
                width, height = img.size
                
                # Azure minimum dimensions
                if width < 50 or height < 50:
                    return False, f"Image too small for Azure: {width}x{height} < 50x50"
                
                # Azure maximum dimensions
                if width > 10000 or height > 10000:
                    return False, f"Image too large for Azure: {width}x{height} > 10000x10000"
                
                # Check DPI for quality warning
                dpi = img.info.get('dpi', (72, 72))
                if isinstance(dpi, tuple):
                    dpi_val = dpi[0]
                else:
                    dpi_val = dpi
                
                recommended_dpi = self.config['azure']['recommended_dpi']
                if dpi_val < 200:
                    logger.warning(f"Low DPI ({dpi_val}) in {os.path.basename(image_path)}. "
                                 f"Recommended: {recommended_dpi} for optimal OCR.")
            
            return True, "Azure compatible"
            
        except Exception as e:
            return False, f"Validation error: {str(e)}"
    
    def prepare_for_azure(self, input_dir: str = None, output_dir: str = None) -> pd.DataFrame:
        """
        Prepare and copy Azure-compatible images to Azure-ready directory.
        
        Args:
            input_dir: Input directory (uses preprocessed by default)
            output_dir: Output directory (uses azure_ready by default)
            
        Returns:
            DataFrame with preparation results
        """
        if input_dir is None:
            input_dir = self.config['paths']['preprocessed']
        if output_dir is None:
            output_dir = self.config['paths']['azure_ready']
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        logger.info(f"Preparing Azure-compatible images from: {input_dir}")
        logger.info(f"Saving to: {output_dir}")
        
        # Get all image files
        supported_formats = self.config['azure']['supported_formats']
        image_files = []
        
        for ext in supported_formats:
            image_files.extend(Path(input_dir).glob(f"*{ext}"))
            image_files.extend(Path(input_dir).glob(f"*{ext.upper()}"))
        
        logger.info(f"Found {len(image_files)} images to validate")
        
        # Process each image
        results = []
        
        for img_path in tqdm(image_files, desc="Preparing for Azure"):
            img_path_str = str(img_path)
            filename = os.path.basename(img_path_str)
            
            # Validate for Azure
            is_valid, validation_msg = self.validate_for_azure(img_path_str)
            
            result = {
                'filename': filename,
                'input_path': img_path_str,
                'azure_compatible': is_valid,
                'validation_message': validation_msg,
                'processed_date': datetime.now().isoformat()
            }
            
            if is_valid:
                # Copy to Azure-ready directory
                output_path = os.path.join(output_dir, filename)
                shutil.copy2(img_path_str, output_path)
                result['azure_ready_path'] = output_path
                self.stats['azure_ready'] += 1
            else:
                result['azure_ready_path'] = None
                self.stats['rejected'] += 1
                self.stats['issues'].append({
                    'file': filename,
                    'reason': validation_msg
                })
            
            results.append(result)
            self.stats['total_processed'] += 1
        
        # Create results DataFrame
        df = pd.DataFrame(results)
        
        # Save results
        self._save_azure_prep_results(df)
        
        # Generate report
        self._generate_azure_prep_report(df)
        
        return df
    
    def generate_azure_batch_config(self, output_dir: str = None) -> str:
        """
        Generate configuration file for Azure batch processing.
        
        Args:
            output_dir: Directory containing Azure-ready images
            
        Returns:
            Path to generated config file
        """
        if output_dir is None:
            output_dir = self.config['paths']['azure_ready']
        
        # Get all Azure-ready files
        image_files = list(Path(output_dir).glob("*.jpg")) + \
                     list(Path(output_dir).glob("*.jpeg")) + \
                     list(Path(output_dir).glob("*.png"))
        
        config_data = {
            'azure_endpoint': self.endpoint or 'YOUR_AZURE_ENDPOINT',
            'api_version': self.config['azure']['api_version'],
            'locale': self.config['azure']['locale'],
            'include_text_details': self.config['azure']['include_text_details'],
            'document_count': len(image_files),
            'documents': [
                {
                    'id': i + 1,
                    'filename': os.path.basename(str(f)),
                    'path': str(f)
                }
                for i, f in enumerate(image_files)
            ]
        }
        
        # Save config
        config_path = os.path.join(output_dir, 'azure_batch_config.yaml')
        with open(config_path, 'w') as f:
            yaml.dump(config_data, f, default_flow_style=False, indent=2)
        
        logger.info(f"Azure batch config saved to: {config_path}")
        return config_path
    
    def _save_azure_prep_results(self, df: pd.DataFrame):
        """Save Azure preparation results."""
        metadata_path = self.config['paths']['metadata']
        os.makedirs(metadata_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save as CSV
        csv_path = os.path.join(metadata_path, f"azure_prep_results_{timestamp}.csv")
        df.to_csv(csv_path, index=False)
        logger.info(f"Azure prep results saved to: {csv_path}")
    
    def _generate_azure_prep_report(self, df: pd.DataFrame):
        """Generate Azure preparation report."""
        report_path = self.config['paths']['validation_reports']
        os.makedirs(report_path, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(report_path, f"azure_prep_report_{timestamp}.txt")
        
        with open(report_file, 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("AZURE AI DOCUMENT INTELLIGENCE PREPARATION REPORT\n")
            f.write("=" * 80 + "\n\n")
            
            f.write(f"Preparation Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Input Directory: {self.config['paths']['preprocessed']}\n")
            f.write(f"Azure Ready Directory: {self.config['paths']['azure_ready']}\n\n")
            
            f.write("AZURE COMPATIBILITY REQUIREMENTS\n")
            f.write("-" * 80 + "\n")
            f.write(f"Max File Size: {self.config['azure']['max_image_size_mb']} MB\n")
            f.write(f"Supported Formats: {', '.join(self.config['azure']['supported_formats'])}\n")
            f.write(f"Recommended DPI: {self.config['azure']['recommended_dpi']}\n")
            f.write(f"API Version: {self.config['azure']['api_version']}\n\n")
            
            f.write("SUMMARY STATISTICS\n")
            f.write("-" * 80 + "\n")
            f.write(f"Total Images Processed: {self.stats['total_processed']}\n")
            f.write(f"Azure Compatible: {self.stats['azure_ready']}\n")
            f.write(f"Rejected: {self.stats['rejected']}\n")
            
            if self.stats['total_processed'] > 0:
                compatibility_rate = (self.stats['azure_ready'] / self.stats['total_processed']) * 100
                f.write(f"Compatibility Rate: {compatibility_rate:.2f}%\n\n")
            
            if self.stats['issues']:
                f.write("COMPATIBILITY ISSUES\n")
                f.write("-" * 80 + "\n")
                for issue in self.stats['issues'][:20]:
                    f.write(f"  • {issue['file']}: {issue['reason']}\n")
                if len(self.stats['issues']) > 20:
                    f.write(f"  ... and {len(self.stats['issues']) - 20} more issues\n")
                f.write("\n")
            
            f.write("NEXT STEPS\n")
            f.write("-" * 80 + "\n")
            f.write("1. Review Azure-ready images in: " + self.config['paths']['azure_ready'] + "\n")
            f.write("2. Set up Azure credentials in .env file\n")
            f.write("3. Use Azure AI Document Intelligence API for OCR processing\n")
            f.write("4. Refer to azure_batch_config.yaml for batch processing\n")
        
        logger.info(f"Azure prep report saved to: {report_file}")
        
        # Print summary
        print("\n" + "=" * 80)
        print("AZURE PREPARATION COMPLETED")
        print("=" * 80)
        print(f"Total Processed: {self.stats['total_processed']}")
        print(f"Azure Compatible: {self.stats['azure_ready']} | Rejected: {self.stats['rejected']}")
        if self.stats['total_processed'] > 0:
            compatibility_rate = (self.stats['azure_ready'] / self.stats['total_processed']) * 100
            print(f"Compatibility Rate: {compatibility_rate:.2f}%")
        print(f"Report: {report_file}")
        print("=" * 80 + "\n")


def main():
    """Main execution function."""
    try:
        # Initialize Azure prep
        azure_prep = AzureDocumentPrep()
        
        # Prepare documents for Azure
        results_df = azure_prep.prepare_for_azure()
        
        # Generate batch config
        config_path = azure_prep.generate_azure_batch_config()
        
        logger.info("Azure preparation completed successfully!")
        logger.info(f"Batch config: {config_path}")
        
    except Exception as e:
        logger.error(f"Azure preparation failed: {e}")
        raise


if __name__ == "__main__":
    main()
